# number2bangla_word_text

Install package
```
pip install number2bangla-word-text==0.0.3

```

# Use:
```
>>> from number2bangla_word_text import number_to_bn_word
>>> number_to_bn_word(100)
   একশো
```

# Limitation
Maximum Number Conversation Limitation 100 Core 

